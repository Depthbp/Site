n = input()
print (n)