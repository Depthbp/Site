n = input()

print(n)