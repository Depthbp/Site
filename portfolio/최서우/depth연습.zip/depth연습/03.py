n = input()
print(n)
