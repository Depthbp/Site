n=input()
print(n)